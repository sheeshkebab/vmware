Changelog
=========

[1.0.0] - 2023-07-24
--------------------

### New Features

- New role for managing keylime server

  This is an ansible role for configuring and deploying the server
  components for Keylime Remote Attestation.
  
  It currently supports Fedora 36+, CentOS Stream 9.1+ and RHEL 9.1+
