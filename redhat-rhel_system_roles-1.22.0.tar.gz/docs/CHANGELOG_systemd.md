Changelog
=========

[1.0.1] - 2023-07-26
--------------------

### Bug Fixes

- fix: allow .j2 suffix for templates, strip off for file/service names (#12)

### Other Changes

- ci: systemd is a python role (#13)

[1.0.0] - 2023-07-20
--------------------

### New Features

- feat: initial import of systemd role content (#9)
